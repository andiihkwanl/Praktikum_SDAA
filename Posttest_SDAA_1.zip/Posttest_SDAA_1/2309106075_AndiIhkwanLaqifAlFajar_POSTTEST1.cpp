#include <iostream>
using namespace std;

void hanoi(int n, string asal, string tujuan, string sementara) {
    if (n == 0) 
        return;
    hanoi(n - 1, asal, sementara, tujuan);
    cout << "Pindahkan piringan " << n << " dari " << asal << " ke " << tujuan << endl;
    hanoi(n - 1, sementara, tujuan, asal);
}

int main() {
    int n = 3;  
    hanoi(n, "asal", "tujuan", "sementara");  
    return 0;
}